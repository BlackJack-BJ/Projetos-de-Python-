import curses

def main(stdscr):
    curses.curs_set(0)  # esconde cursor
    stdscr.keypad(True)

    x, y = 0, 0  # posição do cursor

    while True:
        stdscr.clear()

        for row in range(3):
            for col in range(3):
                if row == y and col == x:
                    stdscr.addstr(row, col * 4, "[ ]")
                else:
                    stdscr.addstr(row, col * 4, " . ")

        key = stdscr.getch()

        if key == curses.KEY_UP and y > 0:
            y -= 1
        elif key == curses.KEY_DOWN and y < 2:
            y += 1
        elif key == curses.KEY_LEFT and x > 0:
            x -= 1
        elif key == curses.KEY_RIGHT and x < 2:
            x += 1
        elif key == ord('q'):
            break

        stdscr.refresh()

curses.wrapper(main)
