from kivy.app import App  # for the window
from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.gridlayout import GridLayout  # for lines and columns
from kivy.uix.boxlayout import BoxLayout


Game_Interface_KV = '''
BoxLayout:
    Button:
        font_size: 40
        background_color: ( .2, .6, .9, 1)
'''
        
                        

"""
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.cols = 3  # columns
        for b in range(9):
            button_extern = Button(
                text="{}",
                font_size=40,
                background_color=(0.2, 0.6, 0.9, 1),
            )
            self.add_widget(button_extern)

            self.cols = 3
            for s in range(9):
                button_small = Button(
                    text=f"{s}",
                    font_size=40,
                    background_color=(0.2, 0.6, 0.9, 1),
                )
                self.add_widget(button_small)
"""


class Principal_Game:  # 3x3 x 3x3...
    def __init__(self):
        pass

    principal_game = [
        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # mini game 0

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 1

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 2

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 3

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 4

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 5

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 6

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 7

        [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ]
        ],  # 8
    ]

    class Mini_Game:  # 3x3
        def __init__(self):
            pass

        mini_game = [
            [
                "0", "1", "2",
                "3", "4", "5",
                "6", "7", "8"
            ],  # whole list

            [
                ["0", "1", "2"],
                ["3", "4", "5"],
                ["6", "7", "8"]
            ],  # horizontal

            [
                ["0", "3", "6"],
                ["1", "4", "7"],
                ["2", "5", "8"]
            ],  # vertical

            [
                ["0", "4", "8"],
                ["2", "4", "6"]
            ]  # diagonals
        ]


class Initialization(App):
    def build(self):  # what appears on the screen when the app initializes
       # return Game_Interface()
       
       return Builder.load_string(Game_Interface_KV)

"""
        for c in range (9):
            btn = Button(
                text = str(c)
            )
            """
            
            
            
class Game_Rules:
    def __init__(self):
        pass


if __name__ == "__main__":
    Initialization().run()