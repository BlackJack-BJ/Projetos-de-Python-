from InquirerPy import inquirer


class Interface:
    def __init__ (self) -> None:
        self.msg1 = "See Tasks"

    def menu(self) -> str:
        menu1 = inquirer.rawlist(
            message = "What would you like to do?",
            choices = [self.msg1]
        ).execute()

        return menu1
