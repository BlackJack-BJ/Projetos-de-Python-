import sqlite3

import level
import missions
import interface


connection = sqlite3.connect("missions.db") # t     he door
cursor = connection.cursor() #the hand that writes
#0 ⇉ False
#1 ⇉ True



class Manage_Points:
    def __init__(self) -> None:
        pass



class User_Data:
    def __init__(self) -> None:
        pass



print(sqlite3.__file__)

"""if __name__ == "__main__":
    game_interface = Interface()
    player_missions = Missions()
    player_points = Manage_Points()


    player_missions.create_db()
    choice = game_interface.menu()

    if choice == game_interface.msg1:
         player_missions.list_tasks()


    player_missions.save_task()"""


