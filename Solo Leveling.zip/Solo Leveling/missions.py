import sqlite3
from rich.table import Table 
from rich.console import Console 


class Missions:
    def __init__ (self) -> None:
            self.connection = connection
            self.cursor = cursor


    def finish (self) -> None:
        self.connection.commit() #saves the changes
        self.connection.close() #do you really want me to explain this!?


    def create_db (self) -> None:
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS missions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task TEXT, 
            points INT, 
            done INT DEFAULT 0                          
        )
                                                                    """) #sends the SQL query to the DB
                 
        self.connection.commit()


    def save_task (self) -> None:
        mission = dict()                        
        while 1:
            try:
                mission["task"] = input("Type your task: ")
                if not mission["task"]:
                    print("Empty entry denied\n")

                    mission["points"] = int(input("Type the value: "))
            except Exception as Error:
                print(f"{Error = }\n") 
                
            else:
                break

        self.cursor.execute(
            "INSERT INTO missions (task, points) VALUES (?, ?)",
            (mission["task"], mission["points"])
        )
        self.finish()


    def list_tasks (self):
        console = Console()
        self.cursor.execute(
                "SELECT id, task, points, done FROM missions"
        )

        tasks: [(),()] = self.cursor.fetchall()

        tasks_formatted = [
                (id_, task, points, "Done" if done else "Pending") for id_, task, points, done in tasks
            ]
                
        if not tasks:
            print("404 - Any task found\n")
            print(tabulate(tasks, headers = ["ID", "Tasks", "Points", "Status"], tablefmt = "grid"))
