class Level:
    def __init__ (self) -> None:
        pass


    def show_levels (self) -> None:
        for c in range(1, 10):
            current_level = c
            next_level = (current_level * 20) + 10

            print(f"Level {current_level} ➩ {next_level} XP")
