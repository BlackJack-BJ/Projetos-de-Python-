from rich.console import Console
from rich.table import Table

console = Console()

table = Table(title="Missions")

table.add_column("ID", justify="right", style="cyan", no_wrap=True)
table.add_column("Task", style="white")
table.add_column("Points", justify="right", style="green")
table.add_column("Status", style="magenta")

tasks = [
    (1, "fazer hamburguerto parar de fumar JS ssla eu vou escrever e ave ver ste donde onde vau vau vau vau svsj vai skejejdjdjd kskskskjdjdjd sla eu sbsbbssnnssnsnsnsnsnse eue82bw", 999, 0),
    (2, "Study Python deeply and consistently every single day", 20, 1),
]

for id_, task, points, done in tasks:
    table.add_row(
        str(id_),
        task,                     # texto longo sem quebrar a tabela
        str(points),
        "Done" if done else "Pending"
    )

console.print(table)
